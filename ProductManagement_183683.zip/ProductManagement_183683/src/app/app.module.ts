import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule} from '@angular/forms'
import { HttpClientModule} from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { SearchFormComponent } from './product/search-form/search-form.component';
import { ProductListComponent } from './product/product-list/product-list.component'
import { PageNotFoundComponent } from './product/page-not-found.component';
import { FindPipe } from './product/find.pipe';





@NgModule({
  declarations: [
    AppComponent,
    SearchFormComponent,
    ProductListComponent,
    PageNotFoundComponent,
    FindPipe,


  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule

  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
