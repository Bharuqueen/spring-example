import { Component, OnInit } from '@angular/core';
import { product } from '../poduct-interface';
import { ProductService } from '../product.service';

@Component({
  selector: 'app-product-list',
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.css']
})
export class ProductListComponent implements OnInit {
  products:product[]
  constructor(private service:ProductService) {}
 

  ngOnInit() {
    this.service.getProducts().subscribe((product)=>{this.products=product});
  }

  /***
	 * Author:Gundla Ajay
	 * Date of Creation: 13-07-2019
	 * Method Name:remove
	 * Parameters:product
	 * Purpose:deletes the particular product based on key entry
	 */
  remove(product)
  {
     let index=this.products.indexOf(product);
     this.products.splice(index,1);
  }
}
