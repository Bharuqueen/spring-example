import { Pipe, PipeTransform } from '@angular/core';
import { product } from './poduct-interface';

@Pipe({
  name: 'find'
})
export class FindPipe implements PipeTransform {

  transform(products:product[], searchKey:any): any {
    if(!products || !searchKey){
      return products;
    }
    return products.filter(product=>product.name.toLowerCase().startsWith(searchKey.toLowerCase()) ||
          product.category.toLowerCase().startsWith(searchKey.toLowerCase()) )
  }

}
