export interface product {
    id: number;
    name: string;
    price: number;
    category: string;

}