import { Component, OnInit } from '@angular/core';
import { product } from '../poduct-interface';
import { ProductService } from '../product.service';

@Component({
  selector: 'app-search-form',
  templateUrl: './search-form.component.html',

  styleUrls: ['./search-form.component.css']
})
export class SearchFormComponent implements OnInit {
  searchKey: any;
  searchKey1: any;
  products: product[]

  constructor(private service: ProductService) { }

  ngOnInit() {
    this.service.getProducts().subscribe((product) => this.products = product);
  }


  /***
	 * Author:Gundla Ajay
	 * Date of Creation: 13-07-2019
	 * Method Name: search
	 * Purpose:finds the particular product based on key entry and displays it further..
	 */
  search() {
    this.searchKey1 = this.searchKey
  }

}
