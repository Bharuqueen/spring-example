package com.cg.proapp.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.proapp.bean.Product;
import com.cg.proapp.dao.ProductDao;
@Service
public class ProductServiceImpl implements ProductService{
	@Autowired
ProductDao productdao;
	@Override
	public List<Product> getAllProducts() {
		// TODO Auto-generated method stub
		return productdao.findAll();
	}

	@Override
	public Product getProductById(int id) {
		// TODO Auto-generated method stub
		return productdao.findById(id).get();
	}
	@Override
	public void updateProduct(Product pro) {
		// TODO Auto-generated method stub
		productdao.save(pro);
	}

	@Override
	public void addProduct(Product pro) {
		// TODO Auto-generated method stub
		productdao.save(pro);
	}

	@Override
	public void deleteProduct(int id) {
		// TODO Auto-generated method stub
		productdao.deleteById(id);
	}

	@Override
	public List<Product> getAllProductByCategory(String category) {
	
		 return  productdao.getProductByCategory(category);
	}

	public boolean validateCategoryAndQuantity(String Category, int Quantity) {
	        if((Category.equals("mobile") || Category.equals("tv") || Category.equals("laptop")) && Quantity>0 )
	        return true;
	        else
	            return false;
	    }

	@Override
	public List<Product> getProductByPrice(double minPrice, double maxPrice) {
		// TODO Auto-generated method stub
		return productdao.getProductByPrice( minPrice, maxPrice) ;
	}



}

