package com.cg.controller;

import org.hibernate.SessionException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.ModelAndView;



@ControllerAdvice
public class GlobalExceptionHandller {
	
	@ExceptionHandler(value = {SessionException.class,Exception.class})
	protected ModelAndView handleConflict(Exception exception)
	{
		ModelAndView modelAndView=new ModelAndView();
		modelAndView.addObject("errormsg",exception.getMessage());
		return modelAndView;
		
	}

}
