package com.cg.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;


import com.cg.bean.Session;
import com.cg.exception.SessionExceptions;
import com.cg.service.ISessionService;

@RestController
public class SessionController {
	
	@Autowired
	private ISessionService service;
	
	/*
	 * Author:boyina suresh
	 * DateOfCreation:7/23/2019
	 * Purpose:This method used to insert the data into the data base
	 */
	
	@RequestMapping(value = "/addSession",method = RequestMethod.POST)
	public List<Session> addSession(@RequestBody Session session) throws SessionExceptions 
	{
		
			return service.addSession(session);
		
		
	}
	
	
	/*
	 * Author:boyina suresh
	 * DateOfCreation:7/23/2019
	 * Purpose:This method used to show the complete data present in the database
	 */
	@RequestMapping(value = "/viewAll",method = RequestMethod.GET)
	public List<Session> viewAllSessions() throws SessionExceptions{
		return service.viewAllSessions();
	}
	
	/*
	 * Author:boyina suresh
	 * DateOfCreation:7/23/2019
	 * Purpose:This method used to delete the data by using id
	 */
	@RequestMapping(value = "/delete/{id}",method = RequestMethod.DELETE)
	public String deleteSession(@PathVariable("id") Integer id) {
		service.deleteSession(id);
		return id+" is deleted sucessfully";
		
	}
	
	/*
	 * Author:boyina suresh
	 * DateOfCreation:7/23/2019
	 * Purpose:This method used to update the duration using id by taking input from the url
	 */
	
	@RequestMapping(value = "/updateDuration/{id}/{duration}")
	public Session update(@PathVariable("id") Integer id,@PathVariable("duration") Integer duration) {
		return service.updateDuration(id, duration);
	}
	
	
	/*
	 * Author:boyina suresh
	 * DateOfCreation:7/23/2019
	 * Purpose:This method used to update the faculty using id by taking input from the url
	 */
	@RequestMapping(value = "/updateFaculty/{id}/{faculty}")
	public Session update(@PathVariable("id") Integer id,@PathVariable("faculty") String faculty) {
		return service.updateFaculty(id, faculty);
	}
	
	
	

}
