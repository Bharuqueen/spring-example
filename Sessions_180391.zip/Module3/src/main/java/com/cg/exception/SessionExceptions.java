package com.cg.exception;

public class SessionExceptions extends Exception {

	public SessionExceptions() {
		super();
	
	}
	
	public SessionExceptions(String Message)
	{
		super(Message);
	}


}
