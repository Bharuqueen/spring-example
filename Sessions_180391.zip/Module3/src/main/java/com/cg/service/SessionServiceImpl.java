package com.cg.service;

import java.util.List;

import org.hibernate.SessionException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.bean.Session;
import com.cg.dao.IsessionDao;
import com.cg.exception.ExceptionMessage;
import com.cg.exception.SessionExceptions;


/*
 * Author:boyina suresh
 * DateOfCreation:7/23/2019
 * Purpose:This class is used to taking the data from the controller and perform operations using dao 
 */
@Service
public class SessionServiceImpl implements ISessionService{
	
	@Autowired
	private IsessionDao repo;
	
	
	/*
	 * Author:boyina suresh
	 * DateOfCreation:7/23/2019
	 * Purpose:This method used to add the data into the database
	 */
	@Override
	public List<Session> addSession(Session session) throws SessionExceptions {
		if(session.getDuration()>3 && (session.getMode().equalsIgnoreCase("ilt") || session.getMode().equalsIgnoreCase("vc")))
		{
			try {
		
		 repo.save(session);
		}
		catch(Exception exception)
		{
			throw new SessionExceptions(ExceptionMessage.Message1);
		}
		}
		return repo.findAll();
	}

	
	/*
	 * Author:boyina suresh
	 * DateOfCreation:7/23/2019
	 * Purpose:This method used to show the complete data present in the database
	 */
	@Override
	public List<Session> viewAllSessions() throws SessionExceptions {
		
		return repo.findAll();
	}
	
	
	/*
	 * Author:boyina suresh
	 * DateOfCreation:7/23/2019
	 * Purpose:This method used to delete the data by using id
	 */
	@Override
	public void deleteSession(Integer id)  {
		repo.deleteById(id);
		
	}
	
	
	
	/*
	 * Author:boyina suresh
	 * DateOfCreation:7/23/2019
	 * Purpose:This method used to update the duration using id by taking input from the url
	 */
	@Override
	public Session updateDuration(Integer id, Integer duration) {
		Session session= repo.findById(id).get();
		session.setDuration(duration);
		repo.save(session);
		return repo.findById(id).get();
	}
	
	/*
	 * Author:boyina suresh
	 * DateOfCreation:7/23/2019
	 * Purpose:This method used to update the faculty using id by taking input from the url
	 */
	@Override
	public Session updateFaculty(Integer id, String faculty) {
		Session session= repo.findById(id).get();
		session.setFaculty(faculty);
		repo.save(session);
		return repo.findById(id).get();
	}

}
