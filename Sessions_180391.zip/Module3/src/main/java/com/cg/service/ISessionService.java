package com.cg.service;

import java.util.List;

import com.cg.bean.Session;
import com.cg.exception.SessionExceptions;

public interface ISessionService {

	List<Session> addSession(Session session) throws SessionExceptions ;
	
	List<Session> viewAllSessions() throws SessionExceptions;
	
	void deleteSession(Integer id);
	
	Session updateDuration(Integer id,Integer duration);
	
	Session updateFaculty(Integer id,String faculty);
	
}
