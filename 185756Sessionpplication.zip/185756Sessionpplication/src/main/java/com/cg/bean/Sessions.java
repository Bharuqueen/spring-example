package com.cg.bean;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Sessions 
{
	@Id
	private int id;
	private String name;
	private int duration;
	private String faculty;
	private String type;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getDuration() {
		return duration;
	}
	public void setDuration(int duration) {
		this.duration = duration;
	}
	public String getFaculty() {
		return faculty;
	}
	public void setFaculty(String faculty) {
		this.faculty = faculty;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	@Override
	public String toString() {
		return "Sessions [id=" + id + ", name=" + name + ", duration=" + duration + ", faculty=" + faculty + ", type="
				+ type + "]";
	}
	

	
}
