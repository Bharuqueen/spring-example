package com.cg.controller;

import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.ModelAndView;

import com.cg.exception.SessionException;

public class GlobalExceptionHandler
{
	@ExceptionHandler(value={SessionException.class,Exception.class})
	protected ModelAndView handlerConflict(Exception exception) {
		ModelAndView mv=new ModelAndView();
		mv.addObject("errorMsg",exception.getMessage());
		mv.setViewName("errorPage");
		return mv;
	}
}
