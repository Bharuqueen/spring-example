package com.cg.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.bean.Sessions;
import com.cg.exception.SessionException;
import com.cg.service.ISessionService;

@RestController
public class SessionController
{
	@Autowired
	private ISessionService service;
	
	@RequestMapping(value = "/createSession", method = RequestMethod.POST)
	public List<Sessions> createSession(@RequestBody Sessions session) throws SessionException  {
		return  service.createSession(session);
	}
	@RequestMapping(value = "/getAllSessions", method = RequestMethod.GET)
	public List<Sessions> getAllSessions() {
		return  service.getAllSessions();
	}
	@RequestMapping(value = "/updateFaculty/{sid}/{faculty}", method = RequestMethod.PUT)
	public Sessions updateFaculty(@PathVariable("sid") Integer id,@PathVariable("faculty")String faculty) {
		return  service.updateFaculty(id,faculty);
	}

	@RequestMapping(value = "/updateDuration/{sid}/{duration}", method = RequestMethod.PUT)
	public Sessions updateDuration(@PathVariable("sid") Integer id,@PathVariable("duration") Integer duration) {
		return  service.updateDuration(id,duration);
	}
	
	@RequestMapping(value = "/delSession/{sid}", method = RequestMethod.DELETE)
	public String delSession(@PathVariable("sid") Integer id) {
		service.delSession(id);
		return  id+" is deleted";
		
	}
	

}
