package com.cg.exception;

public interface MessageException {
	String MESSAGE1="Data not inserted properly use appropriate validations";
}
