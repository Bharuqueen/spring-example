package com.cg.service;

import java.util.List;

import com.cg.bean.Sessions;
import com.cg.exception.SessionException;

public interface ISessionService
{
	List<Sessions> createSession(Sessions session) throws SessionException;
	List <Sessions> getAllSessions();
	Sessions updateFaculty(Integer id, String faculty);
	Sessions updateDuration(Integer id, Integer duration);
	void delSession(Integer id);
}
