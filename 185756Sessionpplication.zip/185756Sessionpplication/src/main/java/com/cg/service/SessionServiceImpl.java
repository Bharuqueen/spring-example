package com.cg.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.bean.Sessions;
import com.cg.dao.ISessionsDao;
import com.cg.exception.MessageException;
import com.cg.exception.SessionException;
@Service
public class SessionServiceImpl implements ISessionService
{
	@Autowired
	private ISessionsDao repository;

	@Override
	public List<Sessions> createSession(Sessions session) throws SessionException {
		if(session.getDuration()>3 && (session.getType().equalsIgnoreCase("ILT")||session.getType().equalsIgnoreCase("VC"))) {
			try {
					repository.save(session);
			}
			catch(Exception exception) {
				throw new SessionException(MessageException.MESSAGE1);
			}
					}
					return  repository.findAll();
				}
	

	@Override
	public List<Sessions> getAllSessions() {
		// TODO Auto-generated method stub
		return  repository.findAll();
	}

	@Override
	public Sessions updateFaculty(Integer id, String faculty) {
		// TODO Auto-generated method stub
		Sessions session=repository.findById(id).get();
		session.setFaculty(faculty);
		Sessions updateFaculty=repository.save(session);
		return updateFaculty;
	}

	@Override
	public Sessions updateDuration(Integer id, Integer duration) {
		// TODO Auto-generated method stub
		Sessions session=repository.findById(id).get();
		session.setDuration(duration);
		Sessions updateDuration=repository.save(session);
		return updateDuration;
		}
	

	@Override
	public void delSession(Integer id) {
		repository.deleteById(id);
		
	}

}
