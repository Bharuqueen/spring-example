package com.session.service;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.session.bean.Session;
import com.session.dao.ISessionRepository;
import com.session.exception.ExceptionMessages;
import com.session.exception.SessionException;

@Service
public class ISessionServiceImpl implements ISessionService {
	@Autowired
	ISessionRepository repository;
	/*Author:Renuka Durga Nekkanti
	 * Created on:23-7-2019
	 * method name:createSession
	 * Description:This method is used for saving the session details
	 * */
	

	@Override
	public List<Session> createSession(Session session) throws SessionException {
		// TODO Auto-generated method stub
		if((session.getDuration()>3)&&(session.getMode().equalsIgnoreCase("ILT")||session.getMode().equalsIgnoreCase("VC"))) {
		try {
		 repository.save(session);
		}catch (Exception e) {
			// TODO: handle exception
			throw new SessionException(ExceptionMessages.MESSAGE);
		}
		}
		else {
			throw new SessionException(ExceptionMessages.MESSAGE1);
		}
		 return repository.findAll();
	}
	/*Author:Renuka Durga Nekkanti
	 * Created on:23-7-2019
	 * method name:deleteSession
	 * Description:This method is used for deleting a session details with respect to specified id
	 * */
	

	@Override
	public void deleteSession(Integer id) throws SessionException {
		// TODO Auto-generated method stub
		try {
		repository.deleteById(id);
		}catch (Exception e) {
			throw new SessionException(ExceptionMessages.MESSAGE2);
		}
		
	}
	/*Author:Renuka Durga Nekkanti
	 * Created on:23-7-2019
	 * method name:viewAllSession
	 * Description:This method is used for viewing all the session details
	 * */

	@Override
	public List<Session> viewAllSession() throws SessionException {
		// TODO Auto-generated method stub
		try {
			return repository.findAll();
		}catch (Exception e) {
			// TODO: handle exception
			throw new SessionException(ExceptionMessages.MESSAGE3);
		}
		}
	/*Author:Renuka Durga Nekkanti
	 * Created on:23-7-2019
	 * method name:updateSession
	 * Description:This method is used for updating session details like duration and faculty name using session id in database
	 * */

	@Override
	public Session updateSession(Integer id, Integer duration, String faculty) {
		// TODO Auto-generated method stub
		Session session=repository.findById(id).get();
		session.setDuration(duration);
		session.setFaculty(faculty);
		repository.save(session);
		return repository.findById(id).get();
	}

	
	}
	

	

