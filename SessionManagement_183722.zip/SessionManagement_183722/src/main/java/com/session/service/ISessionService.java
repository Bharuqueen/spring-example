package com.session.service;

import java.util.List;

import com.session.bean.Session;
import com.session.exception.SessionException;

public interface ISessionService {


List<Session> createSession(Session session) throws SessionException;

void deleteSession(Integer id) throws SessionException;

List<Session> viewAllSession() throws SessionException;

Session updateSession(Integer id, Integer duration, String faculty);
}


