package com.session.exception;

public interface ExceptionMessages {

	String MESSAGE = "session details not saved due to internal error";
	String MESSAGE1 = "duration should be more than 3 and session mode should be ITL or VC";
	String MESSAGE2 = "cannot delete session,session with this particular id does not exists";
	String MESSAGE3 = "cannot view session details as session details are empty";

}
