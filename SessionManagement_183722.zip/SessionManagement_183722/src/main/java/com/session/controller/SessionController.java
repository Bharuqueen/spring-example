package com.session.controller;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.session.bean.Session;
import com.session.exception.SessionException;
import com.session.service.ISessionService;

@RestController
public class SessionController {
	@Autowired
	private ISessionService service;
	@RequestMapping(value = "/createSession", method = RequestMethod.POST)
	public List<Session> createSession(@RequestBody Session session) throws SessionException {
		return  service.createSession(session);
	}
	@RequestMapping(value = "/deleteSession/{sessionId}", method = RequestMethod.DELETE)
	public String deleteSession(@PathVariable("sessionId") Integer id) throws SessionException {
		service.deleteSession(id);
		return  id+" is deleted";
	
	}
	@RequestMapping(value = "/viewAllSession", method = RequestMethod.GET)
	public List<Session> getAllProducts() throws SessionException {
		return  service.viewAllSession();
	}
	@RequestMapping(value = "/updateSession/{id}/{duration}/{facultyName}",method = RequestMethod.POST)
	public Session update(@PathVariable("id") Integer id,@PathVariable("duration") Integer duration,@PathVariable("facultyName") String faculty ) {
		return service.updateSession(id, duration,faculty);
		
	}



}
