package com.cg.exceptions;

public class ProductDoesNotExistException extends RuntimeException { //INcase the product is not in the database,Handled by GProductExceptionHAndler
	
	public ProductDoesNotExistException(String id)
	{
		super("Product with given id "+id+" does not exist!");
	}
	
}
