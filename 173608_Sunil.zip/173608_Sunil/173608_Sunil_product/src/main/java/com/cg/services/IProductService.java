package com.cg.services;

import java.util.List;

import org.springframework.stereotype.Service;

import com.cg.products.Product;

@Service
public interface IProductService {

	void createProduct(Product product);
	void updateProduct(Product product);
	void deleteProduct(Product product);
	List<Product> viewProducts();
	Product findProductById(String id);
}
