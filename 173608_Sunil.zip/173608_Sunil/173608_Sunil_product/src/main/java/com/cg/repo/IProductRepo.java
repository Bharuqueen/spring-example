package com.cg.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cg.products.Product;

@Repository //indicates that this class is a repository component 
public interface IProductRepo extends JpaRepository<Product, String> {
	//Note:The IMPL is auto generated,The IMPL is of JPARepository type,whose methods are used by this interface
}
