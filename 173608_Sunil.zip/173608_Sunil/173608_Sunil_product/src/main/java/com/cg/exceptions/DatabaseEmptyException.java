package com.cg.exceptions;

public class DatabaseEmptyException extends RuntimeException { //INcase the database is Empty,Handled by GProductExceptionHAndler
	
	public DatabaseEmptyException()
	{
		super("The Database is Empty!");
	}
}
