package com.cg.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;

@ControllerAdvice //Signifies that this class is a global exception handler for all the exceptions Being thrown.
public class GProductExceptionHandler {

	@ExceptionHandler({Exception.class}) //Exception Handler annotation signifies that this method handle conflicts will handle All incoming conflicts
	protected ResponseEntity<String> handleExceptions(Exception exception,WebRequest request)
	{
		String message=exception.getMessage();
		return new ResponseEntity<String>(message,HttpStatus.NOT_FOUND);
	}
	
}
