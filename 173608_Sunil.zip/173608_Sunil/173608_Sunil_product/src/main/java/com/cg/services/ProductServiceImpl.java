package com.cg.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.exceptions.DatabaseEmptyException;
import com.cg.exceptions.ProductDoesNotExistException;
import com.cg.products.Product;
import com.cg.repo.IProductRepo;

@Service //This annotation indicates that this class is a service Component
public class ProductServiceImpl implements IProductService {

	@Autowired private IProductRepo repo;  //Here the service class has a dependency of repository,which is auto-created and provided by Spring-Boot
	
	@Override
	public void createProduct(Product product) {
	
		repo.save(product); //Inbuilt Method of JPARepository which saves a given entity into the database
	}

	@Override
	public void updateProduct(Product product) {
		// TODO Auto-generated method stub
		Optional<Product> temp=repo.findById(product.getId()); //to check if object is present
		if(temp.isPresent())
		{
			repo.save(product);  //Inbuilt Method of JPARepository which saves a given entity into the database
		}
		else
		{
			throw new ProductDoesNotExistException(product.getId()); //throws exception if not found
		}
	}

	@Override
	public void deleteProduct(Product product) {
		// TODO Auto-generated method stub
		repo.delete(product); //Inbuilt Method of JPARepository which deletes a given entity from the database
		
	}

	@Override
	public List<Product> viewProducts() {
		// TODO Auto-generated method stub
		List<Product> productList=repo.findAll(); //to check if object is present
		if(productList.isEmpty()==true)
		{
			throw new DatabaseEmptyException(); //throws exception if not found
		}
		return productList; //Inbuilt Method of JPARepository which retrives all the entries in database
	}

	@Override
	public Product findProductById(String id) {
		// TODO Auto-generated method stub
		Optional<Product> temp=repo.findById(id); //to check if object is present
		if(!temp.isPresent())
		{
			throw new ProductDoesNotExistException(id); //throws exception if not found
		}
		return temp.get(); //Inbuilt Method of JPARepository which retrives a single entity entries from the database based on ID
	}

}
