package com.cg.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.products.Product;
import com.cg.services.IProductService;

@RestController //USING REST CONTROLLER means we can automatically MAP the request,Without having to define response body,since RestCOntroller combines functionalities of controller and response body 
@RequestMapping("/products") //RequestMapping maps the url request with the required functionality
public class ProductController {
	
	//BELOW IS THE USAGE OF CRUD FUNCTIONALITIES
	
	
	@Autowired private IProductService service; //Here the Controller class has a dependency of service,which is auto-created and provided by Spring-Boot
	
	@PostMapping("/create") //a shortcut to HTTP:POST method provided by RestAPI
	public ResponseEntity<String> save(@RequestBody Product product) //response entity is a message delivered to the browser to indicate the status of the request.
	{
		try
		{
			service.createProduct(product);
			return new ResponseEntity<String>("Product saved",HttpStatus.OK);
		}
		catch(Exception exception)
		{
			return new ResponseEntity<String>("Unable to save Product",HttpStatus.CONFLICT); 
		}
	}
	
	
	@PutMapping("/update") //a new functionality annotation provided by RestAPI to perform updation of the entities of the current table
	public ResponseEntity<String> update(@RequestBody Product product)
	{
		try
		{
			service.updateProduct(product);
			return new ResponseEntity<String>("Product updated",HttpStatus.OK); 
		}
		catch(Exception ex)
		{
			return new ResponseEntity<String>("Unable to update Product",HttpStatus.CONFLICT); 
		}
	}
	
	
	@DeleteMapping("/delete")  //a new functionality annotation provided by RestAPI to perform deletion of the entities of the current table
	public ResponseEntity<String> delete(@RequestBody Product product) //RequestBody takes the Java Object,and converts it to JSON
	{
		try
		{
			service.deleteProduct(product);
			return new ResponseEntity<String>("Product deleted",HttpStatus.OK);
		}
		catch(Exception ex)
		{
			return new ResponseEntity<String>("Unable to delete Product",HttpStatus.CONFLICT); 
		}
	}
	
	
	@GetMapping("/view-all") //a shortcut to HTTP:POST method provided by RestAPI
	public List<Product> findAll()
	{
		return service.viewProducts();
	}
	
	 
	@GetMapping("/{id}") //a shortcut to HTTP:POST method provided by RestAPI
	public Product findById(@PathVariable String id)//PathVariable signifies the path-url,as in,it intakes the input url's request and utlizes a value from it,In this case ID.
	{
		return service.findProductById(id);
	}
	

}
