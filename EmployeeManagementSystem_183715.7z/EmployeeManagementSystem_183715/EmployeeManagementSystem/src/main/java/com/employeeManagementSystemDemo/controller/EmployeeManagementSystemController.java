package com.employeeManagementSystemDemo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.employeeManagementSystemDemo.dto.Employee;
import com.employeeManagementSystemDemo.exception.EmployeeManagementSystemException;
import com.employeeManagementSystemDemo.service.IEmployeeManagementSystemService;

@RestController
public class EmployeeManagementSystemController {
	@Autowired
	private IEmployeeManagementSystemService iEmployeeManagementSystemService ;

	/*
	 * Author:Vyshnavi Julakanti 
	 * Created on:"23-07-2019"
	 * Purpose:"Calling create employee method by taking parameters from json object through postman"
	 */
	@RequestMapping(value = "/createEmployee", method = RequestMethod.POST)
	public List<Employee> createEmployee(@RequestBody Employee employee) throws EmployeeManagementSystemException{
		return  iEmployeeManagementSystemService.createEmployee(employee);
	}

	/*
	 * Author:Vyshnavi Julakanti 
	 * Created on:"23-07-2019"
	 * Purpose:"updating employee method by taking parameters from json object through postman"
	 */

	@RequestMapping(value = "/updateEmployee/{employeeId}/{designation}", method = RequestMethod.PUT)
	public Employee updateEmployee(@PathVariable("employeeId") Integer employeeId,@PathVariable("designation") String designation) throws EmployeeManagementSystemException{
		return  iEmployeeManagementSystemService.updateEmployee(employeeId,designation);
	}

	/*
	 * Author:Vyshnavi Julakanti 
	 * Created on:"23-07-2019"
	 * Purpose:"Deteting an employee method by taking employee id as a parameter from json object through postman"
	 */


	@RequestMapping(value = "/deleteEmployee/{employeeId}", method = RequestMethod.DELETE)
	public String deleteEmployee(@PathVariable("employeeId") Integer employeeId) throws EmployeeManagementSystemException{
		iEmployeeManagementSystemService.deleteEmployee(employeeId);
		return  "Employee with Id: "+employeeId+" is deleted";
	}
	

	/*
	 * Author:Vyshnavi Julakanti 
	 * Created on:"23-07-2019"
	 * Purpose:"viewing employee list through postman"
	 */

	@RequestMapping(value = "/getEmployeeList", method = RequestMethod.GET)
	public List<Employee> getEmployeeList() throws EmployeeManagementSystemException{
		return  iEmployeeManagementSystemService.viewEmployeesList();
	}

	/*
	 * Author:Vyshnavi Julakanti 
	 * Created on:"23-07-2019"
	 * Purpose:"getting employee by taking id as a parameter from json object through postman"
	 */

	@RequestMapping(value = "/getEmployeeById/{employeeId}", method = RequestMethod.GET)
	  public Employee getEmployeeById(@PathVariable("employeeId") Integer employeeId) throws EmployeeManagementSystemException {
		  return iEmployeeManagementSystemService.getEmployeeById(employeeId);
       }


	/*
	 * Author:Vyshnavi Julakanti 
	 * Created on:"23-07-2019"
	 * Purpose:"getting employee list by taking department name as a parameter and listing list of employees from json object through postman"
	 */

	@RequestMapping(value = "/getEmployeeByDepartment/{departmentName}", method = RequestMethod.GET)
	  public List<Employee> viewEmployeesByDepartment(@PathVariable("departmentName") String departmentName) throws EmployeeManagementSystemException {
		  return iEmployeeManagementSystemService.viewEmployeesByDepartment(departmentName);
       }
	
	
	  @RequestMapping(value = "/updateEmployee", method = RequestMethod.PUT)
	  public List<Employee> updateEmployees(@RequestBody Employee employee) throws
	  EmployeeManagementSystemException{ return (List<Employee>)
	  iEmployeeManagementSystemService.updateEmployees(employee); }
	 
	 
	 
}