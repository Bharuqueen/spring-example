package com.employeeManagementSystemDemo.dto;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
@Entity
public class Employee implements Serializable {
	@Id
	@GeneratedValue
	@Column(name="EMP_ID") 	
	private Integer emp_Id;
	@Column(name="NAME")
	private String name;
	@Column(name="DESIGNATION")
	private String designation;
	@Column(name="DEPT_NAME")
	private String dept_Name;
	@Column(name="SALARY")
	private Double salary;
	public Employee() {
		super();
	}
	
	public Integer getEmp_Id() {
		return emp_Id;
	}
	public void setEmp_Id(Integer emp_Id) {
		this.emp_Id = emp_Id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	public String getDept_Name() {
		return dept_Name;
	}
	public void setDept_Name(String dept_Name) {
		this.dept_Name = dept_Name;
	}
	public Double getSalary() {
		return salary;
	}
	public void setSalary(Double salary) {
		this.salary = salary;
	}
	@Override
	public String toString() {
		return "Employee [emp_Id=" + emp_Id + ", name=" + name + ", designation=" + designation + ", dept_Name="
				+ dept_Name + ", salary=" + salary + "]";
	}
	

}
