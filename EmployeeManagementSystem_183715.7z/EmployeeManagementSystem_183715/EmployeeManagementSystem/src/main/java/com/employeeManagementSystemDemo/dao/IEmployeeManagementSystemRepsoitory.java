package com.employeeManagementSystemDemo.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.employeeManagementSystemDemo.dto.Employee;


@Repository
public interface IEmployeeManagementSystemRepsoitory extends JpaRepository<Employee, Integer> {

}
