package com.employeeManagementSystemDemo.service;


import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.persistence.Column;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.employeeManagementSystemDemo.dao.IEmployeeManagementSystemRepsoitory;
import com.employeeManagementSystemDemo.dto.Employee;
import com.employeeManagementSystemDemo.exception.EmployeeManagementSystemException;
import com.employeeManagementSystemDemo.exception.ExceptionMessage;

@Service
public class EmployeeManagementSystemService implements IEmployeeManagementSystemService {
	@Autowired
	private IEmployeeManagementSystemRepsoitory iEmployeeManagementSystemRepository;
	/*
	 * Author:Vyshnavi Julakanti 
	 * Created on:"23-07-2019"
	 * Purpose:"implementing logic to create employee method by taking parameters from json object through postman"
	 */
	@Override
	public List<Employee> createEmployee(Employee employee) throws EmployeeManagementSystemException{
		try {
			iEmployeeManagementSystemRepository.save(employee);
		}
		catch(Exception e){
			throw new EmployeeManagementSystemException(ExceptionMessage.MESSAGE1);
		}
		return  iEmployeeManagementSystemRepository.findAll();
		
	}
	@Override
	
	
	/*
	 * public Employee updateEmployee(Integer empId, String departmentName) throws
	 * EmployeeManagementSystemException { Employee emp; Employee
	 * employeedb=iEmployeeManagementSystemRepository.findById(empId).get();
	 * employeedb.setDept_Name(departmentName); try{
	 * emp=iEmployeeManagementSystemRepository.save(employeedb);
	 * 
	 * } catch(Exception e){ throw new
	 * EmployeeManagementSystemException(ExceptionMessage.MESSAGE2); } return emp;
	 * 
	 * }
	 */
	 
	public Employee updateEmployees(Employee employee) throws EmployeeManagementSystemException {
		Optional<Employee> employeelist=iEmployeeManagementSystemRepository.findById(employee.getEmp_Id());
		Employee updatedEmpl=employeelist.get();
		updatedEmpl.setName(employee.getName());
		updatedEmpl.setDesignation(employee.getDesignation());
		updatedEmpl.setDept_Name(employee.getDept_Name());
		updatedEmpl.setSalary(employee.getSalary());
		iEmployeeManagementSystemRepository.save(updatedEmpl);
		    return updatedEmpl;
		
	}
	@Override
	public void deleteEmployee(Integer employeeId) throws EmployeeManagementSystemException {
		try {
		iEmployeeManagementSystemRepository.deleteById(employeeId);
		}
		catch(Exception e){
			throw new EmployeeManagementSystemException(ExceptionMessage.MESSAGE3);
		}
	}
	@Override
	public List<Employee> viewEmployeesList() throws EmployeeManagementSystemException {
		try {
		return  iEmployeeManagementSystemRepository.findAll();
		}
		catch(Exception e){
			throw new EmployeeManagementSystemException(ExceptionMessage.MESSAGE4);
		}
	}
	@Override
	public Employee getEmployeeById(Integer employeeId) throws EmployeeManagementSystemException {
		try {
			return iEmployeeManagementSystemRepository.findById(employeeId).get();
		}

		catch(Exception e){
			throw new EmployeeManagementSystemException(ExceptionMessage.MESSAGE5);
		}
	}
	@Override
	public List<Employee> viewEmployeesByDepartment(String departmentName) throws EmployeeManagementSystemException {
		List<Employee> employeeList=iEmployeeManagementSystemRepository.findAll();
		 List<Employee> totalList=new ArrayList<>();
		 try {
			 for(Employee p:employeeList) {
				 if(p.getDept_Name().equals(departmentName)) {
					totalList.add(p); 
				 }
		   }
		 }
         catch(Exception e){
				throw new EmployeeManagementSystemException(ExceptionMessage.MESSAGE6);
			}
		 return totalList;
		}
	@Override
	public Employee updateEmployee(Integer empId, String departmentName) throws EmployeeManagementSystemException {
		// TODO Auto-generated method stub
		return null;
	}
		
		

}
