package com.employeeManagementSystemDemo.exception;

public class EmployeeManagementSystemException  extends Exception {

	public EmployeeManagementSystemException() {
		
	}
	public EmployeeManagementSystemException(String message) {
		
	}
	
	

}
