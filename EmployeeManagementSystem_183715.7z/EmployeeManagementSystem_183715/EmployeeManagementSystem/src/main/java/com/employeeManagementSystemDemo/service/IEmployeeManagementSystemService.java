package com.employeeManagementSystemDemo.service;

import java.util.List;
import java.util.List;
import java.util.Optional;

import org.springframework.http.ResponseEntity;

import com.employeeManagementSystemDemo.dto.Employee;
import com.employeeManagementSystemDemo.exception.EmployeeManagementSystemException;

public interface IEmployeeManagementSystemService {
	List<Employee> createEmployee(Employee employee) throws EmployeeManagementSystemException;
	Employee updateEmployee(Integer empId, String departmentName) throws EmployeeManagementSystemException;
	void deleteEmployee(Integer employeeId) throws EmployeeManagementSystemException;
	List<Employee> viewEmployeesList() throws EmployeeManagementSystemException;
	Employee getEmployeeById(Integer employeeId) throws EmployeeManagementSystemException;
	List<Employee> viewEmployeesByDepartment(String departmentName) throws EmployeeManagementSystemException;
	Employee updateEmployees(Employee employee) throws EmployeeManagementSystemException;
	

}
