package com.employeeManagementSystemDemo.exception;

public interface ExceptionMessage {
	String MESSAGE1="cannot create an employee due to internal error";
	String MESSAGE2 = "Cannot Update Employee";
	String MESSAGE3 = "cannot delete Employee";
	String MESSAGE4 = "unable to list employee details";
	String MESSAGE5 = "error in viewing employee details";
	String MESSAGE6 = "unable to list employee details based on department";
	

}
